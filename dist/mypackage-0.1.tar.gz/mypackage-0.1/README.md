# mypackage

This library was created to provide solution to advanced data wrangling processes

# How to install
...